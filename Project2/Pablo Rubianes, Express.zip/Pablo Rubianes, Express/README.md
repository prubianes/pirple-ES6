## Project 2
Just open the index.html